<?php session_start(); ?>
<!DOCTYPE html>
<html>
<h2>
    <title>Animals names with pictures learning English</title>
    <meta charset="utf-8">
	<link rel="stylesheet" href="css/lesson2.css">
<body>
    
        <div class="right_column">
    <h1 style="text-align: center;"><span>Animal names vocabulary with pictures and words</span></h1>
    <p style="text-align: center;"><img src="image/listofanimals.jpg" alt="Learning animals names with pictures" title="Learning animals names with pictures" width="760"></p>
    <h2 style="text-align: center;"><span style="color: #ff0000;"><strong><em><span style="font-family: 'arial black', 'avant garde'; font-size: medium;">List of animals names&nbsp;</span></em></strong></span></h2>
    <table style="background-color: #fcfdc2; margin-left: auto; margin-right: auto;">
    <tbody>
    <tr>
    <td>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Sheep</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Cat</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Dog</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Camel</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Crocodile &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Polar bear</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;&nbsp;</span></p>
    </td>
    <td>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Cow</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Horse</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Pig</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Elephant &nbsp; &nbsp;&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Bear</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Giraffe</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    </td>
    <td>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Goose &nbsp; &nbsp;&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Cock</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Hen</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Fox</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Wolf</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Elk</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    </td>
    <td>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Mouse</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Frog</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Kangaroo &nbsp; &nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Ant</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Dragon fly</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Grass hopper &nbsp; &nbsp;&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    </td>
    <td>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Owl</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Deer</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Turtle</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Bee</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Ladybird &nbsp; &nbsp;&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Worm</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    </td>
    <td>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Monkey</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Raabbit</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Hippo</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Fly</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Mosquito &nbsp; &nbsp;&nbsp;</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp; Butterfly</span></p>
    <p><span style="font-size: medium; font-family: helvetica;">&nbsp;</span></p>
    </td>
    </tr>
    </tbody>
    </table>
    
   
   
    <button onclick="window.location.href = 'Menu-Lesson.php';" style="width: auto;margin: 100px 0px 0px 1000px;"> RETURN TO MENU LESSON</button>
</html>