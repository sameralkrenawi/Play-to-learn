<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>     
    	<title> Lesson !</title>
        <meta charset="utf-8">
		<link rel="stylesheet" href="css/lesson4.css">
	</head>
<body>
    <div class='lesson1-form'>
        <div class='texte'>
        <p><h2>Lesson-syllables</h2></p>
        <li>little:&nbsp;&nbsp; lit <span class="Answer_Red">-</span>tle</li>
        <li>petal:&nbsp;&nbsp; pet <span class="Answer_Red">-</span>al</li>
        <li>turtle:&nbsp;&nbsp; tur <span class="Answer_Red">-</span>tle</li>
        <li>ankle:&nbsp;&nbsp; an <span class="Answer_Red">-</span> kle</li>
        <li>riddle:&nbsp;&nbsp; rid <span class="Answer_Red">-</span>dle</li>
        <li>arrow:&nbsp;&nbsp; ar <span class="Answer_Red">-</span>row</li>
        <li>nickel:&nbsp;&nbsp; nick <span class="Answer_Red">-</span>el</li>
        <li>cotton:&nbsp;&nbsp; cot <span class="Answer_Red">-</span>ton</li>
        <li>student:&nbsp;&nbsp; stu <span class="Answer_Red">-</span>dent</li>
        <li>teacher:&nbsp;&nbsp; teach <span class="Answer_Red">-</span>er</li>
        <li>children:&nbsp;&nbsp; chil <span class="Answer_Red">-</span>dren</li>
        <li>pottery:&nbsp;&nbsp; pot <span class="Answer_Red">-</span> ter <span class="Answer_Red">-</span> y</li>
        <li>learning:&nbsp;&nbsp; 
        learn <span class="Answer_Red">-</span> ing</li><li>textbook:&nbsp;&nbsp; 
        text <span class="Answer_Red">-</span> book</li><li>watching:&nbsp;&nbsp; 
        watch <span class="Answer_Red">-</span> ing</li><li>screaming:&nbsp;&nbsp; 
        scream <span class="Answer_Red">-</span> ing</li>
        <li>misbehaving:&nbsp;&nbsp; mis <span class="Answer_Red">-</span> be <span class="Answer_Red">-</span> 
        hav <span class="Answer_Red">-</span> ing</li></ul>
        </div>
    </div>

    <style type="text/css">
        body {
        background-image:url(image/imageLesson1.jpg);
        background-color:0;
        }
    </style>
    
    <buttton onclick="window.location.href = 'Menu-Lesson.php';"> RETURN TO MENU LESSON</buttton>
</body>


</html>
-->