<?php session_start();
$_SESSION['image']="";
header('location:/testupload.php');
exit();
?>